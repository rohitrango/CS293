#include "prodcon.h"
using namespace std;

prodcon::prodcon() {
	head = end = NULL;
	curSize = totalSize = 0;
}

prodcon::~prodcon() {
	deleteNodeUtil(head);
}

void prodcon::initialize(int num) {
	totalSize = num;
}

void prodcon::deleteNodeUtil(node* root) {
	if(root==NULL)
		return;
	deleteNodeUtil(root->next);
	delete root;
}

void prodcon::print() {
	node* start = head;
	if(start==NULL) {
		cout<<"null\n";
		return;	
	}
	else {
		while(start->next!=NULL) {
			cout<<start->data<<" ";
			start = start->next;
		}
		cout<<start->data<<endl;			//last element
		// cout<<"\b";		//to handle the extra space
		// cout<<endl;
	}
}

bool prodcon::enqueue(int val) {
	if(curSize == totalSize)		//size full, cant enqueue anymore
		return false;
	
	else {

		node *newNode = new node;
		newNode->data = val;
		newNode->next = NULL;

		if(head==NULL) {			// no element
			end = newNode;
			head = newNode;
			curSize++;
		}
		else {
			end->next = newNode;
			end = newNode;
			curSize++;
		}

		return true;

	}
}

int prodcon::dequeue() {
	if(head==NULL)
		return -1;
	else {
		curSize--;
		int v = head->data;
		head = head->next;
		return v;
	}

	return -1000;		//may be used for debugging
}


void prodcon::growListSize(int num) {
	totalSize += num;
}

////////////////////////////////////////////////////////////////////////
// Main function here
////////////////////////////////////////////////////////////////////////

int main() {
	prodcon Q;

	char command;
	int val,ctr;
	bool queued;

	while(true) {
		cin>>command;

		if(command=='i') {
			cin>>val;
			Q.initialize(val);
		}

		else if(command=='p') {
			cin>>ctr;
			for(int i=0;i<ctr;i++) {
				cin>>val;
				queued = Q.enqueue(val);
			}
		}

		else if(command=='c') {
			cin>>ctr;
			for(int i=0;i<ctr;i++)
				val = Q.dequeue();
		}

		else if(command=='g') {
			cin>>val;
			Q.growListSize(val);
		}

		else if(command=='d')
			Q.print();

		else if(command=='q')
			break;

	} 
}