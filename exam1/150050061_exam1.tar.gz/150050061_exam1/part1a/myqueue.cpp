#include "myqueue.h"
using namespace std;


myqueue::myqueue() {
	head = end = NULL;
	size = 0;
}

myqueue::~myqueue(){
	deleteNodeUtil(head);
}

void myqueue::deleteNodeUtil(node *root) {
	if(root==NULL)
		return;
	deleteNodeUtil(root->next);
	delete root;
}

bool myqueue::enqueue(int val) {
	node *newNode = new node;
	newNode->data = val;
	newNode->next = NULL;

	if(head==NULL) {			// no element
		end = newNode;
		head = newNode;
		size++;
	}
	else {
		end->next = newNode;
		end = newNode;
		size++;
	}

	return true;
}

int myqueue::dequeue() {
	if(head==NULL)
		return -1;
	else {
		size--;
		int v = head->data;
		head = head->next;
		return v;
	}

	return -1000;		//may be used for debugging
}

void myqueue::print() {
	node* start = head;
	if(start==NULL) {
		cout<<"null\n";
		return;	
	}
	else {
		while(start->next!=NULL) {
			cout<<start->data<<" ";
			start = start->next;
		}
		cout<<start->data<<endl;			//last element
		// cout<<"\b";		//to handle the extra space
		// cout<<endl;
	}

}

// main function defined here


int main() {
	myqueue Q;
	char command;
	int ctr,val;
	bool queued;

	while(true) {
		cin>>command;			//input the command
		
		if(command=='e') {
			cin>>ctr;
			for(int i=0;i<ctr;i++) {
				cin>>val;
				queued = Q.enqueue(val);
			}
		}

		else if(command=='p') {
			Q.print();
		}

		else if(command == 'd') {
			cin>>ctr;
			for(int i=0;i<ctr;i++)
				val = Q.dequeue();
		}

		else if(command == 'q') {
			break;
		}
	}			//end of while loop


}

