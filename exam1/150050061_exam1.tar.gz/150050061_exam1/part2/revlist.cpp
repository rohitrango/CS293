#include <iostream>
using namespace std;

class myqueue{

	// Internal struct which stores node related information.
    struct node
    {
        int data;           // value in node is of type int
        node * next;
    };

	node* head;             // use this pointer for start of queue
	size_t size;

	//extra variable
	node *end;
// add variables, functions and function keywords as needed
	void deleteNodeUtil(node *root);
public:
	myqueue() ;        // constructor, desctuctor
	~myqueue();

	bool enqueue(int); // add element to queue, return success/failure
	int dequeue();     // remove element from queue. return element or -1 (if not element)

	void print();      // print queue in FIFO order. print null if list empty
	void reverse(int num);
};


//Implementation
myqueue::myqueue() {
	head = end = NULL;
	size = 0;
}

myqueue::~myqueue(){
	deleteNodeUtil(head);
}

void myqueue::deleteNodeUtil(node *root) {
	if(root==NULL)
		return;
	deleteNodeUtil(root->next);
	delete root;
}

bool myqueue::enqueue(int val) {
	node *newNode = new node;
	newNode->data = val;
	newNode->next = NULL;

	if(head==NULL) {			// no element
		end = newNode;
		head = newNode;
		size++;
	}
	else {
		end->next = newNode;
		end = newNode;
		size++;
	}

	return true;
}

int myqueue::dequeue() {
	if(head==NULL)
		return -1;
	else {
		size--;
		int v = head->data;
		head = head->next;
		return v;
	}

	return -1000;		//may be used for debugging
}

void myqueue::print() {
	node* start = head;
	if(start==NULL) {
		cout<<"null\n";
		return;	
	}
	else {
		while(start->next!=NULL) {
			cout<<start->data<<" ";
			start = start->next;
		}
		cout<<start->data<<endl;			//last element
		// cout<<"\b";		//to handle the extra space
		// cout<<endl;
	}

}

void myqueue::reverse(int num) {		//reverse the list taking batches of size 'num'
	
	if(head==NULL)		// no or one element, do nothing
		return;
	else if(head->next==NULL)
		return;

	//initialization
	node *curNode,*prevNode,*nextNode;				// for reversing the array
	node *tempHead = NULL, *tempEnd = head, *nextEnd = NULL;	//to keep track of previous batch

	// initialize reversing pointers
	curNode = head;
	prevNode = NULL;
	nextNode = head->next;

	//since we need to reset the values
	head = end = NULL;
	
	int index=1;		//index to keep count of the batch size

	while(index <= size) {

		curNode->next = prevNode;
		prevNode = curNode;
		curNode = nextNode;
		if(nextNode->next!=NULL)			//only skip this operation if its the last node
			nextNode = nextNode->next;

		if(index%num==0 or index==size) {			// connect the previous reversed batch to the new batch
			if(head==NULL) {		//baseCase
				head = prevNode;
				tempHead = head;
				nextEnd = curNode;
			}
			else {
				tempEnd->next = prevNode;
				tempEnd = nextEnd;
				tempEnd->next = NULL;
				tempHead = prevNode;

				nextEnd = curNode;
			}
		}	
		index++;
	}
	end = tempEnd;

	// the invariant maintained here is - tempHead and tempEnd store the head and end of the previous batch
	// Maintaining end pointers helps in O(1) time in in inserting/removing
}



//Main function 
int main() {
	myqueue Q;
	char command;
	int ctr,val;
	bool queued;

	while(true) {
		cin>>command;			//input the command
		
		if(command=='i') {
			cin>>ctr;
			for(int i=0;i<ctr;i++) {
				cin>>val;
				queued = Q.enqueue(val);
			}
		}

		else if(command=='p') {
			Q.print();
		}

		else if(command == 'r') {
			cin>>val;
			Q.reverse(val);
		}

		else if(command == 'q') {
			break;
		}
	}			//end of while loop


}