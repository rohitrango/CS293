#include "list_of_list.h"

int main(){

	datastore<int> x;
	char ch;
	cin>>ch;
	while(ch!='q'){
		
		// implement rest of the input commands here. eg. for 'i' (insert), 'p' (print) etc 
		cin>>ch;
	}

	return 0;
}
